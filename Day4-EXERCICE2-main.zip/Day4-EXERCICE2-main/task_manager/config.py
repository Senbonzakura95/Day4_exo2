import os

TASKS_FILE = os.getenv("TASKS_FILE_PATH", "tasks.json")